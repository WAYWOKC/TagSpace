
import React, { useState, useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { Toaster } from "@/components/ui/toaster";
import { Users, Target, Crown, Menu } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { TagTimer } from "@/components/TagTimer";
import "leaflet/dist/leaflet.css";

function App() {
  const { toast } = useToast();
  const [gameMode, setGameMode] = useState("free");
  const [position, setPosition] = useState(null);
  const [isTagging, setIsTagging] = useState(false);
  const [playerId, setPlayerId] = useState(null);
  const [nearbyPlayers, setNearbyPlayers] = useState([]);
  const [playerData, setPlayerData] = useState(null);

  useEffect(() => {
    initializePlayer();
    setupRealtimeSubscription();
    checkExpiredTags();
  }, []);

  useEffect(() => {
    if ("geolocation" in navigator) {
      const watchId = navigator.geolocation.watchPosition(
        async (position) => {
          const newPosition = [position.coords.latitude, position.coords.longitude];
          setPosition(newPosition);
          
          if (playerId) {
            await updatePlayerPosition(newPosition);
            await findNearbyPlayers(newPosition);
          }
        },
        (error) => {
          toast({
            title: "Location Error",
            description: "Please enable location services to play TagChain",
            variant: "destructive",
          });
        }
      );

      return () => navigator.geolocation.clearWatch(watchId);
    }
  }, [playerId]);

  const checkExpiredTags = async () => {
    const interval = setInterval(async () => {
      if (!playerId) return;

      const { data: player } = await supabase
        .from("players")
        .select("*")
        .eq("id", playerId)
        .single();

      if (player?.tag_expires_at && new Date(player.tag_expires_at) < new Date()) {
        await supabase
          .from("players")
          .update({
            is_it: true,
            tag_expires_at: null
          })
          .eq("id", player.previous_tagger_id);

        await supabase
          .from("players")
          .update({
            is_it: false,
            tag_expires_at: null,
            previous_tagger_id: null
          })
          .eq("id", playerId);

        toast({
          title: "Tag Expired!",
          description: "You didn't tag anyone in time. The tag has reverted to the previous player.",
          variant: "destructive"
        });
      }
    }, 60000);

    return () => clearInterval(interval);
  };

  const initializePlayer = async () => {
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (user) {
      const { data: existingPlayer } = await supabase
        .from("players")
        .select()
        .eq("user_id", user.id)
        .single();

      if (existingPlayer) {
        setPlayerId(existingPlayer.id);
        setPlayerData(existingPlayer);
      } else {
        const { data: newPlayer, error } = await supabase
          .from("players")
          .insert({
            user_id: user.id,
            nickname: `Player${Math.floor(Math.random() * 1000)}`,
            game_mode: gameMode,
          })
          .select()
          .single();

        if (error) {
          toast({
            title: "Error",
            description: "Failed to initialize player",
            variant: "destructive",
          });
        } else {
          setPlayerId(newPlayer.id);
          setPlayerData(newPlayer);
        }
      }
    }
  };

  const setupRealtimeSubscription = () => {
    const channel = supabase
      .channel('player_updates')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'players'
      }, payload => {
        if (payload.new && payload.new.id === playerId) {
          setPlayerData(payload.new);
        } else if (payload.new) {
          setNearbyPlayers(current => {
            const filtered = current.filter(p => p.id !== payload.new.id);
            return [...filtered, payload.new];
          });
        }
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const updatePlayerPosition = async (newPosition) => {
    const { error } = await supabase
      .from("players")
      .update({
        latitude: newPosition[0],
        longitude: newPosition[1],
        last_active: new Date().toISOString(),
        game_mode: gameMode,
      })
      .eq("id", playerId);

    if (error) {
      console.error("Error updating position:", error);
    }
  };

  const findNearbyPlayers = async (currentPosition) => {
    const [lat, lng] = currentPosition;
    const radius = 0.01;

    const { data: players, error } = await supabase
      .from("players")
      .select("*")
      .neq("id", playerId)
      .eq("game_mode", gameMode)
      .gte("last_active", new Date(Date.now() - 5 * 60 * 1000).toISOString())
      .filter("latitude", "gte", lat - radius)
      .filter("latitude", "lte", lat + radius)
      .filter("longitude", "gte", lng - radius)
      .filter("longitude", "lte", lng + radius);

    if (error) {
      console.error("Error finding nearby players:", error);
    } else {
      setNearbyPlayers(players || []);
    }
  };

  const handleTag = async () => {
    if (!position || !playerId) return;

    setIsTagging(true);
    const nearestPlayer = findNearestPlayer();

    if (nearestPlayer) {
      try {
        const expiresAt = new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString();
        
        const { error: tagError } = await supabase.from("tags").insert({
          tagger_id: playerId,
          tagged_id: nearestPlayer.id,
          latitude: position[0],
          longitude: position[1],
          game_mode: gameMode,
          expires_at: expiresAt
        });

        if (tagError) throw tagError;

        const { error: playerError } = await supabase
          .from("players")
          .update({
            is_it: true,
            tag_expires_at: expiresAt,
            previous_tagger_id: playerId
          })
          .eq("id", nearestPlayer.id);

        if (playerError) throw playerError;

        await supabase
          .from("players")
          .update({
            is_it: false,
            tag_expires_at: null,
            previous_tagger_id: null
          })
          .eq("id", playerId);

        toast({
          title: "Tagged!",
          description: `You successfully tagged ${nearestPlayer.nickname}! They have 48 hours to tag someone else.`,
        });
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to register tag",
          variant: "destructive",
        });
      }
    } else {
      toast({
        title: "No players nearby",
        description: "Move closer to other players to tag them!",
      });
    }

    setTimeout(() => setIsTagging(false), 2000);
  };

  const findNearestPlayer = () => {
    if (!position || !nearbyPlayers.length) return null;

    return nearbyPlayers.reduce((nearest, player) => {
      if (!player.latitude || !player.longitude) return nearest;

      const distance = calculateDistance(
        position[0],
        position[1],
        player.latitude,
        player.longitude
      );

      if (!nearest || distance < nearest.distance) {
        return { ...player, distance };
      }
      return nearest;
    }, null);
  };

  const calculateDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  return (
    <div className="h-screen w-screen overflow-hidden relative">
      <div className="map-container">
        {position && (
          <MapContainer
            center={position}
            zoom={16}
            className="h-full w-full"
            zoomControl={false}
          >
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            />
            <Marker position={position}>
              <Popup>You are here!</Popup>
            </Marker>
            {nearbyPlayers.map((player) => (
              player.latitude && player.longitude && (
                <Marker
                  key={player.id}
                  position={[player.latitude, player.longitude]}
                >
                  <Popup>
                    <div className="flex flex-col gap-2">
                      <span className="font-bold">{player.nickname}</span>
                      {player.is_it && <span className="text-red-500">Tagged!</span>}
                    </div>
                  </Popup>
                </Marker>
              )
            ))}
          </MapContainer>
        )}
      </div>

      <div className="controls-container h-full w-full flex flex-col justify-between">
        <div className="p-4">
          <Button variant="secondary" size="icon" className="bg-black/50 hover:bg-black/70">
            <Menu className="h-6 w-6" />
          </Button>
        </div>

        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="p-6 glass-card rounded-t-3xl"
        >
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold text-white">TagChain</h1>
            <Button variant="ghost" size="icon">
              <Menu className="h-6 w-6" />
            </Button>
          </div>

          {playerData?.is_it && (
            <div className="mb-4">
              <TagTimer expiresAt={playerData.tag_expires_at} />
            </div>
          )}

          <div className="grid grid-cols-3 gap-4 mb-6">
            <Button
              variant={gameMode === "free" ? "default" : "secondary"}
              onClick={() => setGameMode("free")}
              className="flex flex-col items-center gap-2 h-20"
            >
              <Target className="h-6 w-6" />
              <span>Free Play</span>
            </Button>
            <Button
              variant={gameMode === "friends" ? "default" : "secondary"}
              onClick={() => setGameMode("friends")}
              className="flex flex-col items-center gap-2 h-20"
            >
              <Users className="h-6 w-6" />
              <span>Friends</span>
            </Button>
            <Button
              variant={gameMode === "bounty" ? "default" : "secondary"}
              onClick={() => setGameMode("bounty")}
              className="flex flex-col items-center gap-2 h-20"
            >
              <Crown className="h-6 w-6" />
              <span>Bounty</span>
            </Button>
          </div>

          <motion.div
            whileTap={{ scale: 0.95 }}
            className="flex justify-center"
          >
            <Button
              size="lg"
              className={`w-full py-8 text-lg font-bold ${
                isTagging ? "pulse-animation" : ""
              }`}
              onClick={handleTag}
              disabled={playerData?.is_it}
            >
              {isTagging ? "Tagging..." : playerData?.is_it ? "You're Tagged!" : "Tag Player"}
            </Button>
          </motion.div>
        </motion.div>
      </div>
      <Toaster />
    </div>
  );
}

export default App;
