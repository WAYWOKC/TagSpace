
import React, { useState, useEffect } from "react";
import { formatTimeLeft } from "@/lib/utils";
import { motion } from "framer-motion";
import { Timer } from "lucide-react";

export function TagTimer({ expiresAt }) {
  const [timeLeft, setTimeLeft] = useState(formatTimeLeft(expiresAt));

  useEffect(() => {
    if (!expiresAt) return;

    const interval = setInterval(() => {
      setTimeLeft(formatTimeLeft(expiresAt));
    }, 60000); // Update every minute

    return () => clearInterval(interval);
  }, [expiresAt]);

  if (!expiresAt || !timeLeft) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-center gap-2 bg-red-500/20 text-red-300 px-4 py-2 rounded-full"
    >
      <Timer className="h-4 w-4" />
      <span className="font-medium">{timeLeft} to tag someone</span>
    </motion.div>
  );
}
